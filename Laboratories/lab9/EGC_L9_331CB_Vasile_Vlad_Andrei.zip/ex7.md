Se observa ca atunci cand se aplica un filtru de tip linear, 
textura cubului generat random se degradeaza, acest filtru
fiind nerecomandat pentru pixelart, intrucat valoarea unui pixel
va fi interpolata din valoarea vecinilor sai, rezultand un desen
blurrat. In schimb, pentru obiecte ce au o textura mai realista, 
aceasta este imbunatatita intr-o anumita masura.